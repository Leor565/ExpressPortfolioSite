var express = require('express');
var app = express();
var Routes = require("./routes/routes");

app.set('view engine', 'ejs');

app.use("/public", express.static("public"));

//Routing part
app.use("/", Routes);


app.listen(3000);
console.log('Server running at http://localhost:3000/');