const express = require("express");
const router = express.Router();


// index page
router.get('/', function(req, res, next) {
    res.render('pages/index');
});

// about page
router.get('/about', function(req, res, next) {
    res.render('pages/about');
});

// projects page
router.get('/projects', function(req, res, next) {
    res.render('pages/projects');
});

// services page
router.get('/services', function(req, res, next) {
    res.render('pages/services');
});

// contact page
router.get('/contact', function(req, res, next) {
    res.render('pages/contact');
});


module.exports = router;